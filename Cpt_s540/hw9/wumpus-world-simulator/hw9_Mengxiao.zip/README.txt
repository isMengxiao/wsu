I use Python3 to run the code, and maybe you need to change the PYTHONPATH to the wumpus-world-simulator folder.
Sometimes my agent cannot find gold at first, which would let the score be lower, please try more time, 20 tries or 30 tries is better.. Like if I try 100 times, it can get higher than 900 average score.
But if only 10 tries, sometime it can get high average score like 700, sometimes it will get a really low score like -25 or even lower.(I know it is because the agent will randomly choose action.)
