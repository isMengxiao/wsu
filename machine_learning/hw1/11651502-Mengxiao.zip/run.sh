python3 hw1_part1_a.py&
python3 hw1_part1_b.py&
python3 hw1_part1_c.py&
python3 hw1_part1_d.py&
python3 hw1_part2_a.py&
python3 hw1_part2_b.py&
python3 hw1_part2_c.py&
python3 hw1_part2_d.py&
