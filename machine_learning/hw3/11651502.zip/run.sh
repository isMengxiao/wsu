#!/bin/bash

python3 hw3_a.py > solution_a.txt
python3 hw3_b.py > solution_b.txt
