# -*- coding: utf-8 -*-

from setuptools import setup

setup(
    name='PBDS',
    version='1.0',
    packages=['PBDS'],
    author="Mengxiao Zhang",
    author_email="mengxiao.zhang@wsu.edu"
)
