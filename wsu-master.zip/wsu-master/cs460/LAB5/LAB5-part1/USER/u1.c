#include "ucode.c"

main()
{
  ubody("one");
}
 
