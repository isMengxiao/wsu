#include "ucode.c"

int main(int argc, char *argv[])
{
  // as sh process
    int pid, status;
    while(1){

    }
}

