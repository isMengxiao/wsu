I have add the step backward and step forward button.
